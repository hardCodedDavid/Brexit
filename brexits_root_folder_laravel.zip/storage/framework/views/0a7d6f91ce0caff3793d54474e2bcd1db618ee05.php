<?php $__env->startSection('title', __('My Credit Card')); ?>
<?php $__env->startSection('card', __('is-active')); ?>
<?php $__env->startSection('page', __('Credit Card')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<?php if(isset($card) && $card->id != null): ?>
	<div class="col-lg-2">
		<a class="c-btn c-btn--danger c-btn--fullwidth" href="/credit-card/add" role="button" aria-haspopup="true" aria-expanded="false">Edit Card</a>
		<br><br>
	</div>
	<?php endif; ?>
	<div class="col-lg-12">
		<div class="c-credit-card u-mb-large">
			<div class="c-credit-card__card">
				<?php if(isset($card) && $card->id != null): ?>
				<img class="c-credit-card__logo" src="<?php echo e(asset('img/logo-visa.png')); ?>" alt="Visa Logo">
				<h5 class="c-credit-card__number"><?php echo e(str_repeat('*', strlen($card->pan) - 4) .' '. substr($card->pan, -4)); ?></h5>
				<p class="c-credit-card__status">Valid Thru <?php echo e($card->expiry); ?></p>
				<?php else: ?>
				<div class="u-text-danger">Please Click <a href="/credit-card/add">HERE</a> to add your card now</div>
				<?php endif; ?>
			</div>
			<div class="c-credit-card__user">
				<h3 class="c-credit-card__user-title">Your Bank Account</h3>
				<p class="c-credit-card__user-meta">
					<span class="u-text-mute">Bank:</span>
                    <?php if(auth()->user()->plan == 'indv'): ?>
                        <?php echo e(ucwords($user->bank_name) ?? $this->minor->bankName); ?>

                    <?php elseif(auth()->user()->plan == 'minr'): ?>
                        <?php echo e(ucwords(auth()->user()->minor->bankName)); ?>

                    <?php elseif(auth()->user()->plan == 'cprbdy'): ?>
                        <?php echo e(ucwords(auth()->user()->coporate->bankName)); ?>

                    <?php elseif(auth()->user()->plan == 'othrs'): ?>
                        <?php echo e(ucwords(auth()->user()->others->bankName)); ?>

                    <?php endif; ?>
				</p>
				<p class="c-credit-card__user-meta">
					<span class="u-text-mute">Account Number:</span>
                    <?php if(auth()->user()->plan == 'indv'): ?>
                        <?php echo e($user->account_number); ?>

                    <?php elseif(auth()->user()->plan == 'minr'): ?>
                        <?php echo e(ucwords(auth()->user()->minor->bankAccountNumber)); ?>

                    <?php elseif(auth()->user()->plan == 'cprbdy'): ?>
                        <?php echo e(ucwords(auth()->user()->coporate->bankAccountNumber)); ?>

                    <?php elseif(auth()->user()->plan == 'othrs'): ?>
                        <?php echo e(ucwords(auth()->user()->others->bankAccountNumber)); ?>

                    <?php endif; ?>
				</p>
				<p class="c-credit-card__user-meta">
					<span class="u-text-mute">Account Name:</span>
                    <?php if(auth()->user()->plan == 'indv'): ?>
                        <?php echo e(ucwords($user->account_holder)); ?>

                    <?php elseif(auth()->user()->plan == 'minr'): ?>
                        <?php echo e(ucwords(auth()->user()->minor->bankAccountHolder)); ?>

                    <?php elseif(auth()->user()->plan == 'cprbdy'): ?>
                        <?php echo e(ucwords(auth()->user()->coporate->bankAccountHolder)); ?>

                    <?php elseif(auth()->user()->plan == 'othrs'): ?>
                        <?php echo e(ucwords(auth()->user()->others->bankAccountHolder)); ?>

                    <?php endif; ?>
				</p>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/creditCard.blade.php ENDPATH**/ ?>