<?php $__env->startSection('title', __('Forget Password')); ?>

<?php $__env->startSection('content'); ?>
<div class="c-card u-mb-xsmall">
    <header class="c-card__header u-pt-large">
        <a class="c-card__icon" href="#!" style="background: white">
        <img style="width:80%" src="<?php echo e(asset('brexits-asset-logo-only.png')); ?>">
        </a>
        <h1 class="u-h3 u-text-center u-mb-zero">PASSWORD RECOVERY</h1>
    </header>
    <form class="c-card__body" method="post" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(session('status')): ?>
            <div class="c-alert c-alert--success">
            <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="c-field u-mb-small">
            <label class="c-field__label">Email</label> 
            <input class="c-input" type="email" name="email" required="" value="<?php echo e(old('email')); ?>"> 
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="u-block u-text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
        <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit" style="background: #CC2B22;">Send Reset Link</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>