<?php
use App\Http\Controllers\Globals as Utils;
use App\Country;

$country = Country::whereName($user->country_residence)->first();
$phoneCode = $country ? $country->phonecode : " ";
?>



<?php $__env->startSection('title', __('Profile')); ?>
<?php $__env->startSection('users', __('true')); ?>

<?php $__env->startSection('head'); ?>
<link href="<?php echo e(asset('assets/css/users/user-profile.css')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/dropify/dropify.min.css')); ?>">
<link href="<?php echo e(asset('assets/css/users/account-setting.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script src="<?php echo e(asset('plugins/dropify/dropify.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/blockui/jquery.blockUI.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/users/account-settings.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ul class="navbar-nav flex-row">
	<li>
		<div class="page-header">
			<nav class="breadcrumb-one" aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="/">Home</a></li>
					<li class="breadcrumb-item"><a href="/admin/home">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="/admin/users">Users</a></li>
					<li class="breadcrumb-item active" aria-current="page"><span>View User</span></li>
				</ol>
			</nav>
		</div>
	</li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.users.' . $user->plan, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/admin/viewUser.blade.php ENDPATH**/ ?>