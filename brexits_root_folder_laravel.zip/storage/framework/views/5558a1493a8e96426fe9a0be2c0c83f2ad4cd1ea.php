<?php $__env->startSection('title', __('My transaction history')); ?>
<?php $__env->startSection('transactions', __('is-active')); ?>
<?php $__env->startSection('page', __('My Transactions')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<div class="c-card__header c-card__header--transparent o-line">
			    <h5><small>My Transactions</small></h5>
			</div>
			<div class="c-table-responsive@desktop">
				<table class="c-table c-table--zebra u-mb-small" id="datatable2">
					<thead class="c-table__head">
						<tr class="c-table__row">
						    
    						<th class="c-table__cell c-table__cell--head">Date</th>
    						<th class="c-table__cell c-table__cell--head">Amount</th>
    						<th class="c-table__cell c-table__cell--head">Status</th>
    						<th class="c-table__cell c-table__cell--head">Type</th>
						</tr>
					</thead>
					<tbody>
					    <?php
    					$i = 1;
    					?>
    					<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    					<tr class="c-table__row c-table__row--danger">
    						
    						<td class="c-table__cell"><?php echo e(date('Y-F-d', strtotime($transaction->created_at))); ?></td>
    					    <td class="c-table__cell">$<?php echo e(number_format($transaction->amount,2)); ?></td>
    						<td class="c-table__cell">
    							<?php if($transaction->status == 'approved'): ?>
    							<div class="badge badge-success px-2 py-2"> <?php echo e($transaction->status); ?></div>
    							<?php else: ?>
    							<div class="badge badge-danger px-2 py-2"> <?php echo e($transaction->status); ?></div>
    							<?php endif; ?>
    						</td>
    						<td class="c-table__cell"><?php echo e($transaction->type); ?></td>
                        </tr>
    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
        <nav class="c-pagination u-mt-small u-justify-between">

            <?php if($transactions->previousPageUrl() != null): ?>
                <a class="c-pagination__control" href="<?php echo e($transactions->previousPageUrl()); ?>">
                    <i class="fa fa-caret-left"></i>
                </a>
            <?php else: ?>
                <a class="" href="">
                </a>
            <?php endif; ?>

            <p class="c-pagination__counter">Page <?php echo e($transactions->currentPage()); ?> of <?php echo e($transactions->lastPage()); ?></p>

            <?php if($transactions->nextPageUrl() != null): ?>
                <a class="c-pagination__control" href="<?php echo e($transactions->nextPageUrl()); ?>">
                    <i class="fa fa-caret-right"></i>
                </a>
            <?php else: ?>
                <a class="" href="">
                </a>
            <?php endif; ?>
        </nav>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/transactions.blade.php ENDPATH**/ ?>