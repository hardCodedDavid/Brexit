<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/css/authentication/form-1.css')); ?>" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/switches.css')); ?>">
    </head>
    <body class="form">
        <div class="form-container">
            <div class="form-form">
                <div class="form-form-wrap">
                    <div class="form-container">
                        <div class="form-content">
                            <?php echo $__env->yieldContent('content'); ?>
                            <p class="terms-conditions">© 2019 All Rights Reserved. <a href="/">BREXITS</a>.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-image">
                <div class="l-image">
                </div>
            </div>
        </div>
        <script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/authentication/form-1.js')); ?>"></script>
    </body>
</html><?php /**PATH /home/brexitsmgt/brexits/resources/views/layouts/admin_auth.blade.php ENDPATH**/ ?>