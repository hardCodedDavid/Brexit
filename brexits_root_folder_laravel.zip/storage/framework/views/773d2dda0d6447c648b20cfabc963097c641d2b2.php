<?php $__env->startSection('title', __('Invetment Plans')); ?>
<?php $__env->startSection('investnow', __('is-active')); ?>
<?php $__env->startSection('page', __('Invest Now')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<div class="c-card__header c-card__header--transparent o-line">
				<h5 class="c-card__title">AVAILABLE INVESTMENT TYPES</h5>
				<div class="c-card__meta">
				</div>
			</div>
			<div class="c-table-responsive@desktop">
				<table class="c-table c-table--zebra u-mb-small" id="datatable2">
					<thead class="c-table__head">
						<tr class="c-table__row">
							<th class="c-table__cell c-table__cell--head">PLAN NAME</th>
							<th class="c-table__cell c-table__cell--head">ACTION</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="c-table__row">
							<td class="c-table__cell"><?php echo e($plan->name); ?></td>
							<td class="c-table__cell">
								<a href="/invest-noww/invest/<?php echo e($plan->slug); ?>" class="c-btn c-btn--secondary" aria-haspopup="true" aria-expanded="false">Invest Now</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/investPlan.blade.php ENDPATH**/ ?>