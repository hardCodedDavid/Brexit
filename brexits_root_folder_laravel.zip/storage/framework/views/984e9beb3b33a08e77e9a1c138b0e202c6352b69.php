<?php $__env->startSection('title', __('My statement history')); ?>
<?php $__env->startSection('statements', __('is-active')); ?>
<?php $__env->startSection('page', __('My Statement')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<div class="c-card__header c-card__header--transparent o-line">
			    <h5><small>My Statement</small></h5>
			</div>
			<div class="c-table-responsive@desktop">
				<table class="c-table c-table--zebra u-mb-small" id="datatable2">
					<thead class="c-table__head">
						<tr class="c-table__row">
						    <th class="c-table__cell c-table__cell--head">Date</th>
						    <th class="c-table__cell c-table__cell--head">Account</th>
    						<th class="c-table__cell c-table__cell--head">Amount Invested</th>
    						<th class="c-table__cell c-table__cell--head">Assets</th>
                            <th class="c-table__cell c-table__cell--head">Roi</th>
                            <th class="c-table__cell c-table__cell--head">Status</th>
						</tr>
					</thead>
					<tbody>
					    <?php
    					$i = 1;
    					?>
    					<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $plan = \App\Plan::where('slug', $transaction->plan)->first();
                            ?>
    					<tr class="c-table__row c-table__row--danger">
    						<td class="c-table__cell"><?php echo e(date('Y-F-d', strtotime($transaction->created_at))); ?></td>
                            <td class="c-table__cell"><?php echo e($plan->name); ?></td>
                            <td class="c-table__cell">$<?php echo e(number_format($transaction->amount_invested,2)); ?></td>

    						<td class="c-table__cell"><?php echo e(ucwords($transaction->asset)); ?></td>
    						<td class="c-table__cell">$<?php echo e(number_format($transaction->roi)); ?></td>
    						<td class="c-table__cell">
                                <?php if( $transaction->status == 'open'): ?>
                                    <div class="c-btn--small c-btn c-btn--success">
                                        Opened
                                    </div>
                                <?php elseif($transaction->status == 'close'): ?>
                                    <div class="c-btn--small c-btn c-btn--danger">
                                        Closed
                                    </div>
                                <?php endif; ?>
                            </td>
    					</tr>
    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
        <nav class="c-pagination u-mt-small u-justify-between">

            <?php if($transactions->previousPageUrl() != null): ?>
                <a class="c-pagination__control" href="<?php echo e($transactions->previousPageUrl()); ?>">
                    <i class="fa fa-caret-left"></i>
                </a>
            <?php else: ?>
                <a class="" href="">
                </a>
            <?php endif; ?>

            <p class="c-pagination__counter">Page <?php echo e($transactions->currentPage()); ?> of <?php echo e($transactions->lastPage()); ?></p>

            <?php if($transactions->nextPageUrl() != null): ?>
                <a class="c-pagination__control" href="<?php echo e($transactions->nextPageUrl()); ?>">
                    <i class="fa fa-caret-right"></i>
                </a>
            <?php else: ?>
                <a class="" href="">
                </a>
            <?php endif; ?>
        </nav>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/statements.blade.php ENDPATH**/ ?>