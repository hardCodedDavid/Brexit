<?php $__env->startSection('title', __('Withdrawals')); ?>
<?php $__env->startSection('withdrawals', __('is-active')); ?>
<?php $__env->startSection('page', __('Withdrawals')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-2">
		<a class="c-btn c-btn--danger c-btn--fullwidth" href="/withdrawals/add" role="button" aria-haspopup="true" aria-expanded="false">Request Withdrawals</a>
		<br><br>
	</div>
	<div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<div class="c-card__header c-card__header--transparent o-line">
			    <small>My Withdrawals</small></h5>
			</div>
			<div class="c-table-responsive@desktop">
				<table class="c-table c-table--zebra u-mb-small" id="datatable2">
					<thead class="c-table__head">
						<tr class="c-table__row">
						    <th class="c-table__cell c-table__cell--head">SN</th>
							<th class="c-table__cell c-table__cell--head">Amount</th>
							<th class="c-table__cell c-table__cell--head">Status</th>
							<th class="c-table__cell c-table__cell--head">Date Requested</th>
							<th class="c-table__cell c-table__cell--head">Date Reviewed</th>
						</tr>
					</thead>
					<tbody>
					    <?php
						$i = 1;
						?>
						<?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="c-table__row c-table__row--danger">
							<td class="c-table__cell"><?php echo e($i++); ?></td>
							<td class="c-table__cell">$<?php echo e(number_format($payout->amount,2)); ?></td>
							<td class="c-table__cell"><?php echo e($payout->status); ?></td>
							<td class="c-table__cell"><?php echo e(date('Y-F-d', strtotime($payout->created_at))); ?></td>
							<td class="c-table__cell"> <?php if($payout->status == 'pending'): ?> Pending Approval <?php else: ?> <?php echo e(date('Y-F-d', strtotime($payout->updated_at))); ?> <?php endif; ?> </td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
        <nav class="c-pagination u-mt-small u-justify-between">

            <?php if($payouts->previousPageUrl() != null): ?>
                <a class="c-pagination__control" href="<?php echo e($payouts->previousPageUrl()); ?>">
                    <i class="fa fa-caret-left"></i>
                </a>
            <?php else: ?>
                <a class="" href="">
                </a>
            <?php endif; ?>

            <p class="c-pagination__counter">Page <?php echo e($payouts->currentPage()); ?> of <?php echo e($payouts->lastPage()); ?></p>

            <?php if($payouts->nextPageUrl() != null): ?>
                <a class="c-pagination__control" href="<?php echo e($payouts->nextPageUrl()); ?>">
                    <i class="fa fa-caret-right"></i>
                </a>
            <?php else: ?>
                <a class="" href="">
                </a>
            <?php endif; ?>
        </nav>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/payouts.blade.php ENDPATH**/ ?>