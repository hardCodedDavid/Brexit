<?php $__env->startSection('title', __('Verify Your Email Address')); ?>

<?php $__env->startSection('content'); ?>
<div class="c-card u-mb-xsmall">
    <header class="c-card__header u-pt-large">
        <a class="c-card__icon" href="#!" style="background: red">
        <img src="<?php echo e(asset('brexits-platform-logo-2.png')); ?>">
        </a>
        <h1 class="u-h3 u-text-center u-mb-zero">Verify Your Email Address</h1>
    </header>
    <form class="c-card__body" method="post" action="<?php echo e(route('verification.resend')); ?>">
        <?php echo csrf_field(); ?>
        <div class="c-alert c-alert--success">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

        </div>
        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

        <?php echo e(__('If you did not receive the email')); ?>,
        <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit"><?php echo e(__('click here to request another')); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/auth/verify.blade.php ENDPATH**/ ?>