<?php
use App\Http\Controllers\Globals as Utils;
?>

<div class="row u-mb-large">
    <div class="col-12">
        <div class="c-tabs">
            <ul class="c-tabs__list c-tabs__list--splitted nav nav-tabs" id="myTab" role="tablist" style="width: 100%; overflow-x: scroll">
                <li class="c-tabs__item"><a class="c-tabs__link active" id="nav-personal-tab" data-toggle="tab" href="#nav-personal" role="tab" aria-controls="nav-personal" aria-selected="true">Personal Details</a></li>
                <li class="c-tabs__item"><a class="c-tabs__link" id="nav-address-tab" data-toggle="tab" href="#nav-address" role="tab" aria-controls="nav-address" aria-selected="false">Address Information</a></li>
                <li class="c-tabs__item"><a class="c-tabs__link" id="nav-identity-tab" data-toggle="tab" href="#nav-identity" role="tab" aria-controls="nav-identity" aria-selected="false">Identity / KYC</a></li>
                <li class="c-tabs__item"><a class="c-tabs__link" id="nav-tax-tab" data-toggle="tab" href="#nav-tax" role="tab" aria-controls="nav-tax" aria-selected="false">Tax</a></li>
                <li class="c-tabs__item"><a class="c-tabs__link" id="nav-bank-tab" data-toggle="tab" href="#nav-bank" role="tab" aria-controls="nav-bank" aria-selected="false">Bank Details</a></li>
            </ul>
            <div class="c-tabs__content tab-content" id="nav-tabContent">
                <div class="c-tabs__pane active" id="nav-personal" role="tabpanel" aria-labelledby="nav-personal-tab">
                    <form action="<?php echo e(route('updatePersonal')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                        <!--<div class="col-lg-2 u-text-center">
								<div class="c-avatar c-avatar--xlarge u-inline-block">
									<?php if($user->id_card != ''): ?>
                            <img class="c-avatar__img" src="<?php echo e(asset($user->id_card)); ?>" alt="Avatar">
									<?php else: ?>
                            <img class="c-avatar__img" src="<?php echo e(Gravatar::get($user->email)); ?>" alt="Avatar">
									<?php endif; ?>
                            </div>
                        </div>-->
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">First Name *</label>
                                    <input class="c-input" type="text" name="firstname" value="<?php echo e($user->firstname); ?>" readonly="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Surname *</label>
                                    <input class="c-input" type="text" name="lastname" value="<?php echo e($user->surname); ?>" readonly="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Username*</label>
                                    <input class="c-input" type="text" name="username" value="<?php echo e($user->username); ?>" readonly="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Date of Birth *</label>
                                    <input class="c-input" type="date" name="dob" value="<?php echo e($user->dob); ?>" required="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Identification Type *</label>
                                    <select class="c-select" name="id_type">
                                        <option value="id no" <?php echo e(($user->id_type == 'id_no')? 'selected': ''); ?>>ID No.</option>
                                        <option value="passport no" <?php echo e(($user->id_type == 'passport no')? 'selected': ''); ?>>Passport No.</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Identification Number *</label>
                                    <input class="c-input" type="text" name="id_number" value="<?php echo e($user->id_number); ?>" required="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Email *</label>
                                    <input class="c-input" type="email" name="email" value="<?php echo e($user->email); ?>" readonly="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Gender <small class="u-text-danger">*</small></label>
                                    <select class="c-select" name="gender" required="">
                                        <option value="">Please select....</option>
                                        <option value="male" <?php echo e($user->gender == 'male'? 'selected' : ''); ?>>Male</option>
                                        <option value="female" <?php echo e($user->gender == 'female' ? 'selected' : ''); ?>>Female</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Country of Birth *</label>
                                    <select class="c-select" name="country_birth" required="">
                                        <?php $__currentLoopData = App\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->name); ?>"  <?php echo e(($user->country_birth == $country->name)? 'selected': ''); ?>><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">City of birth *</label>
                                    <input class="c-input" type="text" name="city" value="<?php echo e($user->city_birth); ?>" required="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Country of Residence *</label>
                                    <select class="c-select"  id="country" name="country_residence" required="" onchange="getPhoneCode(this)">
                                        <?php $__currentLoopData = App\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->name); ?>" data-code="<?php echo e($country->phonecode); ?>" <?php echo e(($user->country_residence == $country->name)? 'selected': ''); ?>><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Marital Status *</label>
                                    <select class="c-select" name="marital_status">
                                        <option value="single" <?php echo e(($user->marital_status == 'single')? 'selected': ''); ?>>Single</option>
                                        <option value="married" <?php echo e(($user->marital_status == 'married')? 'selected': ''); ?>>Married</option>
                                        <option value="divorced" <?php echo e(($user->marital_status == 'divorced')? 'selected': ''); ?>>Divorced</option>
                                        <option value="widowed" <?php echo e(($user->marital_status == 'widowed')? 'selected': ''); ?>>Widowed</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="c-field__label">Mobile Number *</label>

                                <div class="c-field has-addon-left">
                                    <span class="c-field__addon u-bg-twitter u-color-white" style="padding: 0 .5em;">
                                        + <span id="phone_code"><?php echo e($phoneCode); ?></span>
                                    </span>
                                    <input type="text" class="c-input" name="phone" value="<?php echo e($user->phone); ?>" required="" >

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Work Number</label>
                                    <input class="c-input" type="text" name="work_number" value="<?php echo e($user->work_number); ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="c-field u-mb-small">
                                    <label class="c-field__label">Citizenship</label>
                                    <select class="c-select" name="nationality" required="">
                                        <?php $__currentLoopData = App\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->name); ?>"  <?php echo e(($user->nationality == $country->name)? 'selected': ''); ?>><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- // second tabs -->
                <div class="c-tabs__pane" id="nav-address" role="tabpanel" aria-labelledby="nav-address-tab">
                    <form action="<?php echo e(route('updateAddress')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <?php if($user->dob != null): ?>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Unit number</label>
                                        <input class="c-input" type="text" name="unit_number" value="<?php echo e($user->unit_number); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Complex Name</label>
                                        <input class="c-input" type="text" name="complex_name" value="<?php echo e($user->complex_number); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Street Number *</label>
                                        <input class="c-input" type="text" name="street_number" value="<?php echo e($user->street_number); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Street Name *</label>
                                        <input class="c-input" type="text" name="street_name" value="<?php echo e($user->street_name); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Suburb *</label>
                                        <input class="c-input" type="text" name="suburb" value="<?php echo e($user->suburb); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">City *</label>
                                        <input class="c-input" type="text" name="city" value="<?php echo e($user->city); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Code *</label>
                                        <input class="c-input" type="text" name="code" value="<?php echo e($user->code); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Country *</label>
                                        <select class="c-select" name="country" required="" onchange="getPhoneCode(this)">
                                            <?php $__currentLoopData = App\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->name); ?>" data-code="<?php echo e($country->phonecode); ?>" <?php echo e(($user->country_residence == $country->name)? 'selected': ''); ?>><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">State *</label>
                                        <input class="c-input" type="text" name="state" value="<?php echo e($user->state); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Update</button>
                                </div>
                            <?php else: ?>
                                <div class="u-text-danger u-text-center">Please update your personal details to update this address information</div>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <!-- // third tabs -->
                <div class="c-tabs__pane" id="nav-identity" role="tabpanel" aria-labelledby="nav-identity-tab">
                    <form action="<?php echo e(route('updateIdentity')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <?php if($user->street_name != null): ?>

                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Passport</label>
                                        <input class="c-input" type="file" name="passport">
                                    </div>


                                </div>

                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Proof of Residence</label>
                                        <input class="c-input" type="file" name="residence_image">
                                    </div>




                                </div>

                                <div class="col-lg-12 u-mt-medium">
                                    <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Update</button>
                                </div>
                            <?php else: ?>
                                <div class="u-text-danger u-text-center">Please update your address information to update Identity / KYC form.</div>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <!-- // fourth tabs -->
                <div class="c-tabs__pane" id="nav-tax" role="tabpanel" aria-labelledby="nav-tax-tab">
                    <form action="<?php echo e(route('updateTax')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="padding:0 2em">
                            <?php if($user->street_name != null): ?>
                                <div class="col-12">
                                    <div class="u-text-center">
                                        <h4 class="u-mb-xsmall">Tax Information.</h4>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="c-choice c-choice--checkbox">
                                        <input class="c-choice__input" id="checkbox1" name="registered" type="checkbox" <?php echo e($user->registered == 'on' ? 'checked' : ''); ?>>
                                        <label class="c-choice__label" for="checkbox1">Are you registered for tax purposes?</label>
                                    </div>
                                </div>

                                <div class="col-12" >
                                    <p class="big-text c-fileitem__name">
                                        Legislation means we need to know where you pay tax. If you only pay tax in South Africa, then please just add your Tax Identification Number.
                                    </p>
                                    <br>
                                    <p class="big-text c-fileitem__name">
                                        If however:
                                    </p>
                                    <p class="big-text">
                                        You pay tax somewhere other than South Africa, then please click on the dropdown and select the country where you pay it, and enter your tax identification number and type for that country.

                                        You pay tax in more than one country, then please enter the correct country, the corresponding tax identification number and type then click on the '+ Add Another Tax Residence' link to add the other country.
                                    </p>
                                    <br>
                                </div>

                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Tax Identification Type*</label>
                                        <select class="c-select" name="tax_type" required="">
                                            <option>Please Select...</option>
                                            <option <?php echo e($user->tax_type == 'sa_tax' ? 'selected' : ''); ?> value="sa_tax">SA: Tax No.</option>
                                            <option <?php echo e($user->tax_type == 'sa_vat' ? 'selected' : ''); ?> value="sa_vat">SA: VAT Registration No.</option>
                                            <option <?php echo e($user->tax_type == 'us_social' ? 'selected' : ''); ?> value="us_social">US: Social Security No.</option>
                                            <option <?php echo e($user->tax_type == 'us_employer' ? 'selected' : ''); ?> value="us_employer">US: Employer Identification No.</option>
                                            <option <?php echo e($user->tax_type == 'us_indv' ? 'selected' : ''); ?> value="us_indv" >US: Individual Taxpayer ID No.</option>
                                            <option <?php echo e($user->tax_type == 'us_tax' ? 'selected' : ''); ?> value="us_tax" >US: Tax ID No. Pending US adoption</option>
                                            <option <?php echo e($user->tax_type == 'us_prep' ? 'selected' : ''); ?> value="us_prep" >US: Preparer Taxpayer ID No.</option>
                                            <option <?php echo e($user->tax_type == 'others' ? 'selected' : ''); ?> value="others" >Other Tax No.</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">What is your tax number? (TIN for US Citizens)*</label>
                                        <input class="c-input" type="text" name="tax_number" value="<?php echo e($user->tax_number); ?>" required="">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Tax Residence *</label>
                                        <select class="c-select" name="tax_residence" required="">
                                            <?php $__currentLoopData = App\Country::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->name); ?>"  <?php echo e(($user->tax_residence == $country->name)? 'selected': ''); ?>><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                </div>

                                <div class="col-12">
                                    <div class="c-choice c-choice--checkbox">
                                        <input class="c-choice__input" id="checkbox2" name="primary_residence" type="checkbox" <?php echo e($user->primary_residence == 'on' ? 'checked' : ''); ?>>
                                        <label class="c-choice__label" for="checkbox2">Primary residence?</label>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Update</button>
                                </div>
                            <?php else: ?>
                                <div class="u-text-danger u-text-center">Please update your address information to update Identity / KYC form.</div>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <!-- // fourth tabs -->
                <div class="c-tabs__pane" id="nav-bank" role="tabpanel" aria-labelledby="nav-bank-tab">
                    <form action="<?php echo e(route('updateBank')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <?php if($user->tax_residence != null): ?>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Bank Name *</label>
                                        <input class="c-input" type="text" name="bank_name" value="<?php echo e($user->bank_name); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Account Type *</label>
                                        <input class="c-input" type="text" name="account_type" value="<?php echo e($user->account_type); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Branch Name *</label>
                                        <input class="c-input" type="text" name="branch_name" value="<?php echo e($user->branch_name); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Branch Code *</label>
                                        <input class="c-input" type="text" name="branch_code" value="<?php echo e($user->branch_code); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Account Number *</label>
                                        <input class="c-input" type="text" name="account_number" value="<?php echo e($user->account_number); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Account Holder *</label>
                                        <input class="c-input" type="text" name="account_holder" value="<?php echo e($user->account_holder); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Bank Country *</label>
                                        <input class="c-input" type="text" name="bank_country" value="<?php echo e($user->bank_country); ?>" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6 ">
                                </div>
                                <div class="col-lg-6 offset-lg-3">
                                    <span class="c-divider has-text c-divider--small u-mv-medium">Other Details</span>
                                </div>
                                <div class="col-lg-12">
                                    <div class="c-field u-mb-small">
                                        <label class="c-field__label">Bitcoin Address</label>
                                        <input class="c-input" type="text" name="bitcoin_address" value="<?php echo e($user->bitcoin_address); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Update</button>
                                </div>
                            <?php else: ?>
                                <div class="u-text-danger u-text-center">Please update your Tax to update Bank details form.</div>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

<script src="<?php echo e(asset('js/scrolling-tabs.js')); ?>"></script>

<script src="<?php echo e(asset('js/demo.js')); ?>"></script>
<?php /**PATH /home/brexitsmgt/brexits/resources/views/user/profile/indv.blade.php ENDPATH**/ ?>