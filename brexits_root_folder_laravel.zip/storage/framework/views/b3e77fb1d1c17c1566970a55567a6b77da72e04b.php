<?php $__env->startSection('title', __('Add Settings')); ?>

<?php $__env->startSection('static', __('true')); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ul class="navbar-nav flex-row">
	<li>
		<div class="page-header">
			<nav class="breadcrumb-one" aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="/">Home</a></li>
					<li class="breadcrumb-item"><a href="/admin/home">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="/admin/settings">Settings</a></li>
					<li class="breadcrumb-item active" aria-current="page"><span><?php echo e((isset($entity))?'Edit':'Add'); ?> Settings</span></li>
				</ol>
			</nav>
		</div>
	</li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-6 col-lg-6 col-sm-12  layout-spacing">
	<div class="widget-content widget-content-area br-6">
		<div class=" mb-4 mt-4">
			<?php if(isset($edit)): ?>

			<?php else: ?>
			<form method="post" action="<?php echo e(route('addSettings')); ?>">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="form-group col-12">
						<label>Email</label>
						<input type="text" name="email" class="form-control" required="" value="<?php echo e(old('email') ?? isset($entity) ? $entity->email : ''); ?>">
					</div>

					<div class="form-group col-12">
						<label>Bitcoin</label>
						<input type="text" name="bitcoin" class="form-control" required="" value="<?php echo e(old('bitcoin') ?? isset($entity) ? $entity->bitcoin : ''); ?>">
					</div>
					<div class="form-group col-12">
						<label>Bank Name</label>
						<input type="text" name="bank_name" class="form-control" required="" value="<?php echo e(old('bank_name') ?? isset($entity) ? $entity->bank_name : ''); ?>">
					</div>
					<div class="form-group col-12">
						<label>Account Number</label>
						<input type="text" name="account_number" class="form-control" required="" value="<?php echo e(old('account_number') ?? isset($entity) ? $entity->account_number : ''); ?>">
					</div>
					<div class="form-group col-12">
						<label>Account Holder</label>
						<input type="text" name="account_holder" class="form-control" required="" value="<?php echo e(old('account_holder') ?? isset($entity) ? $entity->account_holder : ''); ?>">
					</div>
					<div class="form-group col-12">
						<label>Bank Country</label>
						<input type="text" name="bank_country" class="form-control" required="" value="<?php echo e(old('bank_country') ?? isset($entity) ? $entity->bank_country : ''); ?>">
					</div>

				</div>
				<button class="btn btn-success btn-lg btn-block" type="submit">ADD</button>
			</form>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/admin/addSetting.blade.php ENDPATH**/ ?>