<?php
use App\Http\Controllers\Globals as Utils;
?>



<?php $__env->startSection('title', __('Transaction history')); ?>
<?php $__env->startSection('funds', __('true')); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/datatables.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/custom_dt_html5.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt-global_style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/table/datatable/button-ext/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/table/datatable/button-ext/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/table/datatable/button-ext/buttons.print.min.js')); ?>"></script>
<script>
    $('#html5-extension').DataTable( {
        dom: '<"row"<"col-md-12"<"row"<"col-md-6"B><"col-md-6"f> > ><"col-md-12"rt> <"col-md-12"<"row"<"col-md-5"i><"col-md-7"p>>> >',
        buttons: {
            buttons: [
                { extend: 'copy', className: 'btn' },
                { extend: 'csv', className: 'btn' },
                { extend: 'excel', className: 'btn' },
                { extend: 'print', className: 'btn' }
            ]
        },
        "oLanguage": {
            "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
            "sInfo": "Showing page _PAGE_ of _PAGES_",
            "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
            "sSearchPlaceholder": "Search...",
           "sLengthMenu": "Results :  _MENU_",
        },
        "stripeClasses": [],
        "lengthMenu": [7, 10, 20, 50],
        "pageLength": 20
    } );
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ul class="navbar-nav flex-row">
	<li>
		<div class="page-header">
			<nav class="breadcrumb-one" aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="/">Home</a></li>
					<li class="breadcrumb-item"><a href="/admin/home">Dashboard</a></li>
					<li class="breadcrumb-item active" aria-current="page"><span>Transfers</span></li>
				</ol>
			</nav>
		</div>
	</li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
	<div class="widget-content widget-content-area br-6">
		<div class="table-responsive mb-4 mt-4">
			<table id="html5-extension" class="table table-hover non-hover" style="width:100%">
				<thead>
					<tr>
						<th>SN</th>
						<th>User</th>
						<th>From</th>
						<th>To</th>
                        <th>Amount</th>
                        <th>Status</th>
						<th>Date</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>

					<?php
					$i = 1;
					?>
					<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $from = \App\Plan::where('slug', $transaction->from)->first();
                            $to = \App\Plan::where('slug', $transaction->to)->first();
                        ?>

                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td>
                                <a href="/admin/users/view/<?php echo e($transaction->user->id); ?>" target="_blank"><?php echo e($transaction->user->username); ?></a>
                            </td>
                            <td><?php echo e($from->name); ?></td>
                            <td><?php echo e($to->name); ?></td>
                            <td>$<?php echo e(number_format($transaction->amount,2)); ?></td>

                            <td>
                                <?php if($transaction->status == 'approved'): ?>
                                    <div class="badge badge-success px-2 py-2"> <?php echo e($transaction->status); ?></div>
                                <?php elseif($transaction->status == 'pending'): ?>
                                    <div class="badge badge-warning px-2 py-2"> <?php echo e($transaction->status); ?></div>
                                <?php else: ?>
                                    <div class="badge badge-danger px-2 py-2"> <?php echo e($transaction->status); ?></div>
                                <?php endif; ?>
                            </td>

                            <td><?php echo e(date('Y-F-d', strtotime($transaction->created_at))); ?></td>
                            <td>

                                <div class="btn-group">
                                    <button type="button" class="btn btn-dark btn-sm">Open</button>
                                    <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down">
                                            <polyline points="6 9 12 15 18 9"></polyline>
                                        </svg>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                                        <?php if($transaction->status == 'pending'): ?>
                                            <a class="dropdown-item" href="/admin/transfers/<?php echo e($transaction->id); ?>/approve">Approve</a>
                                            <a class="dropdown-item" href="/admin/transfers/<?php echo e($transaction->id); ?>/decline">Decline</a>
                                        <?php endif; ?>
                                        <a class="dropdown-item" href="/admin/transfers/<?php echo e($transaction->id); ?>/delete">Delete</a>
                                    </div>
                                </div>

                            </td>
                        </tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/admin/transfers.blade.php ENDPATH**/ ?>