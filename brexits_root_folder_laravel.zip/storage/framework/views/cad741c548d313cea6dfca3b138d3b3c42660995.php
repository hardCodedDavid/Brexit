<?php $__env->startSection('title', __('Withdraw now')); ?>
<?php $__env->startSection('withdrawals', __('is-active')); ?>
<?php $__env->startSection('page', __('WIthdraw Now')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<form class="c-card__body" method="post" action="<?php echo e(route('addPayout')); ?>">
		        <?php echo csrf_field(); ?>
		        <div class="c-field u-mb-small">
		            <label class="c-field__label">From </label>
		            <input class="c-input" type="text" value="<?php echo e(ucwords($plan->name)); ?>" readonly="">
		            <input type="hidden" name="plan" class="form-control" value="<?php echo e($plan->slug); ?>">
		        </div>
                <div class="c-field u-mb-small">
                    <label class="c-field__label">Payment Method</label>
                    <select class="c-input" class="form-control" name="payment_method" required="">
                        <option value="">Please select...</option>
                        <option value="bank">Bank Deposit</option>
                        <option value="bitcoin">Bitcoin</option>
                    </select>
                </div>

		        <div class="c-field u-mb-small">
		            <label class="c-field__label">Amount to withdraw</label>
		            <input class="c-input" type="number" name="amount" required="" step="any">
		        </div>
		        <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Withdraw</button>
		    </form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/addPayoutN.blade.php ENDPATH**/ ?>