<?php
use App\Http\Controllers\Globals as Utils;
?>



<?php $__env->startSection('title', __('Inter-Account Transfer')); ?>
<?php $__env->startSection('transfer', __('is-active')); ?>
<?php $__env->startSection('page', __('Inter account Transfer')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<form class="c-card__body" method="post" action="<?php echo e(route('transfer')); ?>">
		        <?php echo csrf_field(); ?>
		        <div class="c-field u-mb-small">
                    <label class="c-field__label">FROM</label>
                    <select class="c-select has-search" name="from" required="">
                        <option value="">Please select....</option>
                        <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($investment->id); ?>"><?php echo e(ucwords(Utils::getPlan($investment->plan)->name)); ?> - $<?php echo e(number_format($investment->amount,2)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

		        <div class="c-field u-mb-small">
                    <label class="c-field__label">TO</label>
                    <select class="c-select has-search" name="plan" required="">
                        <option value="">Please select....</option>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($plan->slug); ?>"><?php echo e(ucwords($plan->name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
		        <div class="c-field u-mb-small">
		            <label class="c-field__label">Amount </label>
		            <input class="c-input" type="number" name="amount" required="" step="any">
		        </div>
		        <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">SUBMIT</button>
		    </form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/transfer.blade.php ENDPATH**/ ?>