<?php $__env->startSection('title', __('Credit Card')); ?>
<?php $__env->startSection('card', __('is-active')); ?>
<?php $__env->startSection('page', __('Add Credit Card')); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="c-card c-card--responsive u-mb-medium">
			<?php if($cards > 0): ?>
			<form class="c-card__body" method="post" action="<?php echo e(route('editCard')); ?>">
		        <?php echo csrf_field(); ?>
		        <div class="c-field u-mb-small">
		            <label class="c-field__label">PAN Code </label>
		            <input class="c-input" type="text" name="pan" value="<?php echo e($card->pan); ?>" required=""> 
		        </div>
		        <div class="c-field u-mb-small">
		            <label class="c-field__label">Expiry </label>
		            <input class="c-input" type="text" name="expiry" value="<?php echo e($card->expiry); ?>" required=""> 
		        </div>
		        <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Edit</button>
		    </form>
			<?php else: ?>
			<form class="c-card__body" method="post" action="<?php echo e(route('addCard')); ?>">
		        <?php echo csrf_field(); ?>
		        <div class="c-field u-mb-small">
		            <label class="c-field__label">PAN Code </label>
		            <input class="c-input" type="text" name="pan" required=""> 
		        </div>
		        <div class="c-field u-mb-small">
		            <label class="c-field__label">Expiry </label>
		            <input class="c-input" type="text" name="expiry" required=""> 
		        </div>
		        <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Add</button>
		    </form>
		    <?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/addCard.blade.php ENDPATH**/ ?>