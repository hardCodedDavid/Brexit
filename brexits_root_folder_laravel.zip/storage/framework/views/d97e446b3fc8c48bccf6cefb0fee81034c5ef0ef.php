<?php
use App\Http\Controllers\Globals as Utils;
use App\Country;

$country = Country::whereName($user->country_residence)->first();
$phoneCode = $country ? $country->phonecode : " ";
?>


<?php $__env->startSection('title', __('Edit Profile')); ?>
<?php $__env->startSection('page', __('Edit Profile')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('user.profile.' . auth()->user()->plan, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script type="text/javascript">
     function getPhoneCode(obj){
         var phone = obj.options[obj.selectedIndex].getAttribute('data-code');
         document.getElementById('phone_code').innerHTML = phone;
     }

    </script>

    <style>
        .big-text{
            font-size: 1em;
        }
    </style>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/user/editprofile.blade.php ENDPATH**/ ?>