<?php if(isset($edit)): ?>
<?php $__env->startSection('title', __('Edit Investment')); ?>
<?php else: ?>
<?php $__env->startSection('title', __('Add Investment')); ?>
<?php endif; ?>
<?php $__env->startSection('investments', __('true')); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<ul class="navbar-nav flex-row">
	<li>
		<div class="page-header">
			<nav class="breadcrumb-one" aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="/">Home</a></li>
					<li class="breadcrumb-item"><a href="/admin/home">Dashboard</a></li>
					<li class="breadcrumb-item"><a href="/admin/investments">Investments</a></li>
					<li class="breadcrumb-item active" aria-current="page"><span><?php echo e((isset($edit))?'Edit':'Add'); ?> Investment</span></li>
				</ol>
			</nav>
		</div>
	</li>
</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-6 col-lg-6 col-sm-12  layout-spacing">
	<div class="widget-content widget-content-area br-6">
		<div class=" mb-4 mt-4">
			<?php if(isset($edit)): ?>

                <form method="post" action="<?php echo e(route('editInvestmentAdminPost', $investment->id)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="form-group col-12">
                            <label>User</label>
                            <select class="form-control" name="user_id" required>
                                <option value="">Please select...</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php if($investment->user_id == $user->id): ?> selected <?php endif; ?>><?php echo e(ucwords($user->username)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-12">
                            <label>Plan</label>
                            <select class="form-control" name="plan" required>
                                <option value="">Please select...</option>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($plan->slug); ?>" <?php if($investment->plan == $plan->slug): ?> selected <?php endif; ?>><?php echo e(ucwords($plan->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group col-12">
                            <label>Amount Invested</label>
                            <input type="number" name="amount_invested" class="form-control" step="any" required value="<?php echo e($investment->amount_invested); ?>">
                        </div>

                        <div class="form-group col-12">
                            <label>ROI</label>
                            <input type="number" name="roi" class="form-control" required step="any" value="<?php echo e($investment->roi); ?>">
                        </div>

                        <div class="form-group col-12">
                            <label>Status</label>
                            <select class="form-control" name="status" required>
                                <option value="">Please select...</option>
                                <?php $__currentLoopData = ['open','close']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php if($investment->status == $status): ?> selected <?php endif; ?>><?php echo e(ucwords($status)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group col-12">
                            <label>Asset</label>
                            <select class="form-control" name="asset" required>
                                <option value="">Please select...</option>
                                <?php $__currentLoopData = ['Equities', 'Fixed Income (bond)', 'Cash', 'Properties', 'Cryptocurrencies', 'EFT\'s', 'Gold', 'Hedge Funds']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($asset); ?>" <?php if($investment->asset == $asset): ?> selected <?php endif; ?>><?php echo e(ucwords($asset)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <button class="btn btn-success btn-lg btn-block" type="submit">Update</button>
                </form>
			<?php else: ?>
			    <form method="post" action="<?php echo e(route('addInvestmentAdmin')); ?>">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="form-group col-12">
						<label>User</label>
						<select class="form-control" name="user" required>
							<option value="">Please select...</option>
							<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($user->email); ?>"><?php echo e(ucwords($user->username)); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group col-12">
						<label>Plan</label>
						<select class="form-control" name="plan" required>
							<option value="">Please select...</option>
							<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($plan->slug); ?>"><?php echo e(ucwords($plan->name)); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

                    <div class="form-group col-12">
                        <label>Amount Invested</label>
                        <input type="number" name="amount_invested" class="form-control" step="any" required>
                    </div>

					<div class="form-group col-12">
						<label>ROI</label>
						<input type="number" name="roi" class="form-control" required step="any">
					</div>

                    <div class="form-group col-12">
                        <label>Status</label>
                        <select class="form-control" name="status" required>
                            <option value="">Please select...</option>
                            <?php $__currentLoopData = ['open','close']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>"><?php echo e(ucwords($status)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-12">
                        <label>Asset</label>
                        <select class="form-control" name="asset" required>
                            <option value="">Please select...</option>
                            <?php $__currentLoopData = ['Equities', 'Fixed Income (bond)', 'Cash', 'Properties', 'Cryptocurrencies', 'EFT\'s', 'Gold', 'Hedge Funds']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($asset); ?>"><?php echo e(ucwords($asset)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
				</div>
				<button class="btn btn-success btn-lg btn-block" type="submit">ADD</button>
			</form>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brexitsmgt/brexits/resources/views/admin/addInvestment.blade.php ENDPATH**/ ?>